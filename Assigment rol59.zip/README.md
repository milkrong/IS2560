# Assignment 1
----

Build a personal website page. **Without any framework or library**

## Introduction

5 html file:
- Index page contains slider show
- Resume page contains personal information
- Gallery page contains some beautiful pictures
- Timeline page contains excellent moment every year
- About page contains a to-do list with progressing about this website

## Knowledge point:

- Css style nesting
- Building slider shows and to-do list with JS
- Style the head with "blur" attribute

## Struggling point:

- Margin and padding
- Fixed footer in a page

## Improvement of assignment:

- More correlated links about the project. 
